# Section 97
## Armed Robberies

**Status:**
Works for Latest game version 0.3.4f4

**How it works:**
Section 97 Adds in Armed Robberies, Buy a Handgun from the arms dealer inside the warehouse, and aim it at a store Clerk (Gas Mart, Taco Ticklers or Casino) and then click E on the register, You can decide to kill the clerk or leave them, But if you leave them they'll call the cops!

**How To Install:**
1. Install MelonLoader https://melonwiki.xyz/#/
2. Drag and drop the .dll and the config folder into the mods folder inside the games directory
3. Play the game and Enjoy your Armed Robberies.

**Configuration:**
Section 97 has various config options that can be found within the MelonPreferences.cfg file.

**Road Map:**
Soon To Be added is:
* Bat robberies at Pawn Shop (Smash the cases with the bat to get items or money)
* Safe Robberies (With a skill based system | Pickpocketing to open)
* At night Robberies (Break into doors using a picklock!)      
